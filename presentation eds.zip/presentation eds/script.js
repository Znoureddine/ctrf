Reveal.initialize({
    width: 1400,
    height: 900,
    hash: true,
    controls: true,
    progress: true,
    center: false,
    slideNumber: 'c/t',
    transition: 'slide',
    backgroundTransition: 'fade',
    margin: 0.1,
    minScale: 0.2,
    maxScale: 2.0,
    
    // Total Navigation Overhaul
    fragments: false, // Force Reveal.js to ignore all fragment states
    keyboard: true,
    touch: true,
    help: false,
    hideAddressBar: true,
    
    // Fast responsive animations
    autoAnimateEasing: 'ease-out',
    autoAnimateDuration: 0.8,
    autoAnimateUnmatched: false
});

let x6Initialized = false;
let x6RoadmapInitialized = false;

// Add a listener for slide changes to trigger specific animations
Reveal.on('slidechanged', event => {
    // Init Network Graph (Slide 7)
    if (!x6Initialized) {
        if (event.currentSlide.querySelector('#network-x6-container')) {
            initX6Network();
            x6Initialized = true;
        }
    }
    // Init Roadmap Module C (Slide 11)
    if (!x6RoadmapInitialized) {
        if (event.currentSlide.querySelector('#module-c-roadmap-container')) {
            initModuleCRoadmap();
            x6RoadmapInitialized = true;
        }
    }
});

// Initialize AntV X6 Roadmap for Module C
function initModuleCRoadmap() {
    const container = document.getElementById('module-c-roadmap-container');
    if (!container || typeof X6 === 'undefined') return;

    const graph = new X6.Graph({
        container: container,
        width: 1380,
        height: 580,
        background: { color: 'transparent' },
        grid: false,
        interacting: false,
    });

    const commonAttrs = {
        body: {
            fill: 'rgba(255, 255, 255, 0.95)',
            stroke: '#0284c7',
            strokeWidth: 2,
            rx: 6, ry: 6
        },
        label: { fill: '#1e293b', fontSize: 11, fontWeight: 'bold' }
    };

    // Define Nodes
    const nodesData = [
        // Clients
        { id: 'inst_fin', x: 50, y: 120, text: 'Inst. Financières\n(Banque/Assu)', stroke: '#10b981' },
        { id: 'epnfd', x: 50, y: 300, text: 'EPNFD', stroke: '#10b981' },
        { id: 'pers_ctrf', x: 50, y: 520, text: 'Personnel CTRF', stroke: '#8b5cf6' },
        // Front & Intranet
        { id: 'ut1', x: 320, y: 120, text: 'UTWEB 1\n10.216.8.39' },
        { id: 'ut2', x: 320, y: 300, text: 'UTWEB 2\n10.216.8.40' },
        { id: 'tweb', x: 320, y: 520, text: 'TWEB\n10.116.120.39', stroke: '#475569' },
        // Apps
        { id: 'app1', x: 600, y: 120, text: 'APP 1\n10.116.88.39:8000' },
        { id: 'app2', x: 600, y: 300, text: 'APP 2\n10.116.88.40:8000' },
        { id: 'app3', x: 600, y: 520, text: 'APP 3\n10.116.88.67:8000' },
        // DBs
        { id: 'db', x: 900, y: 120, text: 'BDD\n10.116.104.39:5432', stroke: '#d97706' },
        { id: 'redis', x: 900, y: 300, text: 'REDIS\n10.116.88.66:6379', stroke: '#d97706' },
        { id: 'elastic', x: 900, y: 520, text: 'Elastic\n10.116.104.67:9200', stroke: '#d97706' },
    ];

    const edgeOpts = {
        attrs: { line: { stroke: '#0ea5e9', strokeWidth: 2, class: 'data-flow-line' } },
        connector: { name: 'smooth' }
    };

    // Edges
    graph.addEdge({ source: 'start', target: 'create', ...edgeOpts });
    graph.addEdge({ source: 'create', target: 'acquisition', ...edgeOpts });
    
    graph.addEdge({ source: 'acquisition', target: 'reject', label: 'Non', ...edgeOpts });
    graph.addEdge({ source: 'reject', target: 'end1', ...edgeOpts });
    graph.addEdge({ source: 'acquisition', target: 'assign', label: 'Oui', ...edgeOpts });
    
    graph.addEdge({ source: 'assign', target: 'process', ...edgeOpts });
    graph.addEdge({ source: 'process', target: 'compliance', ...edgeOpts });
    
    graph.addEdge({ source: 'compliance', target: 'archive_ds', label: 'Non', ...edgeOpts });
    graph.addEdge({ source: 'archive_ds', target: 'end2', ...edgeOpts });
    
    // Nodes definition matching Diapositive12.JPG
    graph.addNode({ id: 'start', x: 30, y: 230, width: 40, height: 40, shape: 'circle', label: 'Début', attrs: commonAttrs });
    graph.addNode({ id: 'create', x: 100, y: 225, width: 110, height: 50, shape: 'rect', label: 'Création de la DS', attrs: commonAttrs });
    graph.addNode({ id: 'acquisition', x: 250, y: 225, width: 90, height: 50, shape: 'polygon', label: 'Acquisition\nde la DS', 
        attrs: { ...commonAttrs, body: { ...commonAttrs.body, refPoints: '0,10 10,0 20,10 10,20' } } // Diamond
    });
    
    graph.addNode({ id: 'reject', x: 250, y: 120, width: 160, height: 50, shape: 'rect', label: 'Archivage\nsans traitement', attrs: commonAttrs });
    graph.addNode({ id: 'assign', x: 380, y: 225, width: 110, height: 50, shape: 'rect', label: 'Assignement\nde la DS', attrs: commonAttrs });
    graph.addNode({ id: 'process', x: 530, y: 225, width: 110, height: 50, shape: 'rect', label: 'Traitement\nde la DS', attrs: commonAttrs });
    
    graph.addNode({ id: 'compliance', x: 540, y: 350, width: 120, height: 70, shape: 'polygon', label: 'Risque\nconfirmé', 
        attrs: { ...commonAttrs, body: { ...commonAttrs.body, refPoints: '0,10 10,0 20,10 10,20' } } 
    });
    
    graph.addNode({ id: 'archive_ds', x: 520, y: 440, width: 150, height: 50, shape: 'rect', label: 'Archivage\navec traitement', attrs: commonAttrs });
    graph.addNode({ id: 'report', x: 680, y: 350, width: 110, height: 50, shape: 'rect', label: 'Rédaction\nd’un rapport', attrs: commonAttrs });
    
    graph.addNode({ id: 'verification', x: 840, y: 350, width: 80, height: 50, shape: 'polygon', label: 'Vérification', 
        attrs: { ...commonAttrs, body: { ...commonAttrs.body, refPoints: '0,10 10,0 20,10 10,20' } } 
    });
    
    graph.addNode({ id: 'diffusion', x: 960, y: 355, width: 150, height: 50, shape: 'rect', label: 'Archivage ou\ndiffusion du rapport', attrs: commonAttrs });
    
    // Ends
    graph.addNode({ id: 'end1', x: 285, y: 40, width: 40, height: 40, shape: 'circle', label: 'Fin', attrs: commonAttrs });
    graph.addNode({ id: 'end2', x: 565, y: 510, width: 40, height: 40, shape: 'circle', label: 'Fin', attrs: commonAttrs });
    graph.addNode({ id: 'end3', x: 1110, y: 355, width: 40, height: 40, shape: 'circle', label: 'Fin', attrs: commonAttrs });
    
    graph.addEdge({ source: 'compliance', target: 'report', label: 'Oui', ...edgeOpts });
    graph.addEdge({ source: 'report', target: 'verification', ...edgeOpts });
    
    graph.addEdge({ 
        source: { cell: 'verification', anchor: 'top' }, 
        target: { cell: 'process', anchor: 'right' }, 
        label: {
            text: 'Non',
            position: {
                distance: 0.05,
                offset: -30,
            },
            attrs: {
                text: { fill: '#ef4444', fontWeight: 'bold' }
            }
        }, 
        ...edgeOpts, 
        router: 'manhattan' 
    });
    graph.addEdge({ source: 'verification', target: 'diffusion', label: 'Oui', ...edgeOpts });
    graph.addEdge({ source: 'diffusion', target: 'end3', ...edgeOpts });

    // Auto-scale content to fit the impressive new large container
    graph.zoomToFit({ padding: 30 });
}

// Initialize AntV X6 Architecture Graph
function initX6Network() {
    const container = document.getElementById('network-x6-container');
    if (!container || typeof X6 === 'undefined') {
        console.warn("X6 context not ready.");
        return;
    }

    // Define Node Style for DataShow (Light theme)
    const getDefaultNode = () => ({
        width: 180,
        height: 70,
        shape: 'rect',
        attrs: {
            body: {
                fill: 'rgba(255, 255, 255, 0.95)',
                stroke: '#0284c7', // Cyan / Light blue
                strokeWidth: 2,
                rx: 8,
                ry: 8,
            },
            label: {
                fill: '#1e293b',
                fontSize: 16,
                fontWeight: 'bold',
            }
        }
    });

    const graph = new X6.Graph({
        container: container,
        width: 1350,
        height: 730,
        background: { color: 'transparent' },
        grid: false,
        interacting: false, // Static for presentation
    });

    // Subgraphs (Groups) using basic rectangles to simulate Zones
    const zones = [
        { id: 'zone-client', x: 10, y: 20, width: 240, height: 680, label: 'Clients / Utilisateurs' },
        { id: 'zone-pub', x: 270, y: 20, width: 280, height: 440, label: 'Zone Publique' },
        { id: 'zone-intranet', x: 270, y: 480, width: 280, height: 220, label: 'Zone Intranet CTRF' },
        { id: 'zone-dmz', x: 570, y: 20, width: 280, height: 680, label: 'Zone DMZ Application' },
        { id: 'zone-db', x: 870, y: 20, width: 280, height: 680, label: 'Zone Base de Données' },
    ];

    zones.forEach(z => {
        graph.addNode({
            x: z.x, y: z.y, width: z.width, height: z.height,
            zIndex: -1,
            attrs: {
                body: { fill: 'rgba(2, 132, 199, 0.03)', stroke: '#cbd5e1', strokeWidth: 1, strokeDasharray: '5 5', rx: 10, ry: 10 },
                label: { text: z.label, refY: 20, fill: '#64748b', fontSize: 13, fontWeight: 'bold' }
            }
        });
    });

    // Define Nodes with corrected coordinates strictly inside their zones
    const nodesData = [
        // Clients (centered around x:40)
        { id: 'inst_fin', x: 40, y: 100, text: 'Inst. Financières\n(Banque/Assu)', stroke: '#10b981' },
        { id: 'pers_ctrf', x: 40, y: 310, text: 'Personnel CTRF', stroke: '#8b5cf6' },
        { id: 'epnfd', x: 40, y: 530, text: 'EPNFD', stroke: '#ef4444' },
        // Front & Intranet (centered around x:320)
        { id: 'ut1', x: 320, y: 100, text: 'UTWEB 1\n10.216.8.39' },
        { id: 'tweb', x: 320, y: 310, text: 'TWEB\n10.116.120.39', stroke: '#475569' },
        { id: 'ut2', x: 320, y: 530, text: 'UTWEB 2\n10.216.8.40', stroke: '#ef4444' },
        // Apps (centered around x:620)
        { id: 'app1', x: 620, y: 100, text: 'APP 1\n10.116.88.39:8000' },
        { id: 'app2', x: 620, y: 310, text: 'APP 2 (Appels API)\n10.116.88.40:8000' },
        { id: 'app3', x: 620, y: 530, text: 'APP 3\n10.116.88.67:8000', stroke: '#ef4444' },
        // DBs (centered around x:920)
        { id: 'db', x: 920, y: 100, text: 'BDD\n10.116.104.39:5432', stroke: '#d97706' },
        { id: 'redis', x: 920, y: 310, text: 'REDIS\n10.116.88.66:6379', stroke: '#d97706' },
        { id: 'elastic', x: 920, y: 530, text: 'Elastic\n10.116.104.67:9200', stroke: '#d97706' },
    ];

    nodesData.forEach(n => {
        let nodeOpts = getDefaultNode();
        nodeOpts.id = n.id;
        nodeOpts.x = n.x;
        nodeOpts.y = n.y;
        nodeOpts.attrs.label.text = n.text;
        if(n.stroke) nodeOpts.attrs.body.stroke = n.stroke;
        graph.addNode(nodeOpts);
    });

    // Define Edges with data flow animation
    const edgesData = [
        // Clients to web
        { src: 'inst_fin', tgt: 'ut1', label: ' HTTPS' },
        { src: 'epnfd', tgt: 'ut2', label: 'HTTPS' },
        { src: 'pers_ctrf', tgt: 'tweb', label: 'VPN' },

        // DB to App internal routing
        { src: 'ut1', tgt: 'app1', label: '' },
        { src: 'ut2', tgt: 'app3', label: '' },
        { src: 'tweb', tgt: 'app2', label: '' },

        // App to Data Layer (All link to all)
        { src: 'app1', tgt: 'db', label: '' },
        { src: 'app1', tgt: 'redis', label: '' },
        { src: 'app1', tgt: 'elastic', label: '' },
        { src: 'app2', tgt: 'db', label: '' },
        { src: 'app2', tgt: 'redis', label: '' },
        { src: 'app2', tgt: 'elastic', label: '' },
        { src: 'app3', tgt: 'db', label: '' },
        { src: 'app3', tgt: 'redis', label: '' },
        { src: 'app3', tgt: 'elastic', label: '' },
    ];

    edgesData.forEach(e => {
        graph.addEdge({
            source: { cell: e.src },
            target: { cell: e.tgt },
            connector: { name: 'smooth' }, // Soft bezier curve perfectly handles 9 overlapping connections
            labels: e.label ? [{ attrs: { label: { text: e.label, fontSize: 11, fill: '#475569' } } }] : [],
            attrs: {
                line: {
                    stroke: '#0ea5e9',
                    strokeWidth: 2,
                    class: 'data-flow-line' // Target CSS Animation
                }
            }
        });
    });

    // Auto-scale the graph to fit the impressive new large container
    graph.zoomToFit({ padding: 20, maxScale: 2 });
}

// Global initialization override just in case it's the first slide (which it isn't here, but safe practice)
document.addEventListener("DOMContentLoaded", function() {
    setTimeout(() => {
        const slide = document.querySelector('section.present');
        if (slide && slide.querySelector('#network-x6-container') && !x6Initialized) {
            initX6Network();
            x6Initialized = true;
        }
    }, 800);
});

// Initialize Particle.js for the dynamic background
document.addEventListener("DOMContentLoaded", function() {
    if(typeof particlesJS !== 'undefined') {
        particlesJS("particles-js", {
            "particles": {
                "number": {
                    "value": 40, // Not too many to keep it clean
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": {
                    "value": "#0284c7" // Darker Cyan accent color for light bg
                },
                "shape": {
                    "type": "circle",
                    "stroke": {
                        "width": 0,
                        "color": "#000000"
                    },
                    "polygon": {
                        "nb_sides": 5
                    }
                },
                "opacity": {
                    "value": 0.3,
                    "random": false,
                    "anim": {
                        "enable": false,
                        "speed": 1,
                        "opacity_min": 0.1,
                        "sync": false
                    }
                },
                "size": {
                    "value": 3,
                    "random": true,
                    "anim": {
                        "enable": false,
                        "speed": 40,
                        "size_min": 0.1,
                        "sync": false
                    }
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#0284c7",
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 1, // Slow elegant movement
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "bounce": false,
                    "attract": {
                        "enable": false,
                        "rotateX": 600,
                        "rotateY": 1200
                    }
                }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": {
                        "enable": true,
                        "mode": "grab" // Link particles to mouse
                    },
                    "onclick": {
                        "enable": true,
                        "mode": "push"
                    },
                    "resize": true
                },
                "modes": {
                    "grab": {
                        "distance": 140,
                        "line_linked": {
                            "opacity": 0.5
                        }
                    },
                    "bubble": {
                        "distance": 400,
                        "size": 40,
                        "duration": 2,
                        "opacity": 8,
                        "speed": 3
                    },
                    "repulse": {
                        "distance": 200,
                        "duration": 0.4
                    },
                    "push": {
                        "particles_nb": 4
                    },
                    "remove": {
                        "particles_nb": 2
                    }
                }
            },
            "retina_detect": true
        });
    }
});
